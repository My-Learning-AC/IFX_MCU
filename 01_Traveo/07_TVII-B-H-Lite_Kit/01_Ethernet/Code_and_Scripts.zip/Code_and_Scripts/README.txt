1) Copy the bb_bsp_tviibh8m.h and paste in the SDL \tviibh8m\hdr\rev_d folder
2) Replace the main_cm7_0.c file under \tviibh8m\src folder
3) Build and flash the code